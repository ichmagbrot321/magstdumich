
import { app, setupPromise } from "../server/app";

export default async function handler(req, res) {
  await setupPromise;
  app(req, res);
}
