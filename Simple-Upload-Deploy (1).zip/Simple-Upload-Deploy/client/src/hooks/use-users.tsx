import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

export function useUserCheck(username: string) {
  return useQuery({
    queryKey: ["user-check", username],
    queryFn: async () => {
      if (!username) return { exists: false };
      const url = buildUrl(api.users.check.path, { username });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to check user");
      return api.users.check.responses[200].parse(await res.json());
    },
    enabled: !!username,
    staleTime: 1000 * 60 * 5, // Cache for 5 mins
  });
}
