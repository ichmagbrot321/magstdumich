import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema, type InsertUser } from "@shared/schema";
import { useLogin, useRegister, useUser } from "@/hooks/use-auth";
import { GlassCard } from "@/components/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [_, setLocation] = useLocation();
  const { data: user, isLoading: isLoadingUser } = useUser();
  
  const loginMutation = useLogin();
  const registerMutation = useRegister();

  // Redirect if already logged in
  if (user) {
    setLocation("/dashboard");
    return null;
  }

  const form = useForm<InsertUser>({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onSubmit = (data: InsertUser) => {
    if (isLogin) {
      loginMutation.mutate(data);
    } else {
      registerMutation.mutate(data);
    }
  };

  const isPending = loginMutation.isPending || registerMutation.isPending;

  if (isLoadingUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-12 w-12 text-white animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative z-10">
      <GlassCard className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-extrabold text-gradient mb-2 tracking-tight">
            Magst du mich?
          </h1>
          <p className="text-gray-600">
            Erstelle deine persönliche Frage-Seite und finde es heraus.
          </p>
        </div>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="username" className="text-gray-700 font-medium ml-1">
              Username
            </Label>
            <Input
              id="username"
              {...form.register("username")}
              className="bg-white/50 border-white/40 focus:bg-white transition-colors h-12 text-lg rounded-xl"
              placeholder="z.B. maxmuster"
              disabled={isPending}
            />
            {form.formState.errors.username && (
              <p className="text-red-500 text-sm ml-1">
                {form.formState.errors.username.message}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-gray-700 font-medium ml-1">
              Passwort
            </Label>
            <Input
              id="password"
              type="password"
              {...form.register("password")}
              className="bg-white/50 border-white/40 focus:bg-white transition-colors h-12 text-lg rounded-xl"
              disabled={isPending}
            />
            {form.formState.errors.password && (
              <p className="text-red-500 text-sm ml-1">
                {form.formState.errors.password.message}
              </p>
            )}
          </div>

          <Button
            type="submit"
            disabled={isPending}
            className="w-full h-12 text-lg font-bold rounded-xl shadow-lg shadow-purple-500/30 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 border-0"
          >
            {isPending ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : isLogin ? (
              "Einloggen"
            ) : (
              "Account erstellen"
            )}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => {
              setIsLogin(!isLogin);
              form.reset();
            }}
            className="text-sm font-medium text-gray-500 hover:text-purple-600 transition-colors"
          >
            {isLogin
              ? "Noch keinen Account? Registrieren"
              : "Bereits registriert? Einloggen"}
          </button>
        </div>
      </GlassCard>
    </div>
  );
}
