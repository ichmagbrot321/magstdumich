import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { useUserCheck } from "@/hooks/use-users";
import { useCreateSession, useUpdateSession } from "@/hooks/use-sessions";
import { GlassCard } from "@/components/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sparkles } from "@/components/Sparkles";
import { FleeingButton } from "@/components/FleeingButton";
import { Loader2, Heart, Music2, Music4 } from "lucide-react";
import confetti from "canvas-confetti";
import { motion, AnimatePresence } from "framer-motion";

export default function PublicQuestion() {
  const [match, params] = useRoute("/u/:username");
  const username = params?.username || "";
  
  const { data: userCheck, isLoading: isCheckingUser } = useUserCheck(username);
  const createSession = useCreateSession();
  const updateSession = useUpdateSession();

  const [step, setStep] = useState<"name" | "question" | "success">("name");
  const [visitorName, setVisitorName] = useState("");
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [noAttempts, setNoAttempts] = useState(0);

  // Sound effects
  const playSuccessSound = () => {
    const audio = new Audio("https://actions.google.com/sounds/v1/cartoon/clang_and_wobble.ogg");
    audio.volume = 0.5;
    audio.play().catch(() => {});
  };

  const handleStart = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!visitorName.trim()) return;
    
    try {
      const session = await createSession.mutateAsync({
        username,
        visitorName,
      });
      setSessionId(session.id);
      setStep("question");
    } catch (err) {
      console.error("Failed to create session", err);
    }
  };

  const handleYes = () => {
    if (!sessionId) return;
    
    playSuccessSound();
    
    // Confetti explosion
    const duration = 3000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#ff0000', '#00ff00', '#0000ff']
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#ff0000', '#00ff00', '#0000ff']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();

    updateSession.mutate({ id: sessionId, saidYes: true });
    setStep("success");
  };

  const handleNoAttempt = () => {
    if (!sessionId) return;
    const newCount = noAttempts + 1;
    setNoAttempts(newCount);
    // Debounce updates slightly in real app, but here direct is fine
    updateSession.mutate({ id: sessionId, noAttempts: newCount });
  };

  if (isCheckingUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="animate-spin text-purple-500 w-8 h-8" />
      </div>
    );
  }

  if (!userCheck?.exists) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <GlassCard>
          <h1 className="text-2xl font-bold text-gray-800">User not found 😕</h1>
          <p className="text-gray-600 mt-2">Dieser Link ist leider ungültig.</p>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative overflow-hidden flex flex-col items-center justify-center p-4">
      <Sparkles />
      
      <AnimatePresence mode="wait">
        {step === "name" && (
          <GlassCard key="step-name" className="w-full max-w-md z-10 text-center">
            <h1 className="text-4xl font-extrabold text-gray-800 mb-6">
              Huhu! 👋
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              Ich habe eine wichtige Frage an dich.<br/>
              Aber zuerst, verrate mir deinen Namen:
            </p>
            
            <form onSubmit={handleStart} className="space-y-4">
              <Input
                autoFocus
                value={visitorName}
                onChange={(e) => setVisitorName(e.target.value)}
                placeholder="Dein Name..."
                className="text-center text-xl h-14 rounded-2xl bg-white/60 border-2 border-white/50 focus:border-purple-400 transition-all"
              />
              <Button 
                type="submit" 
                disabled={!visitorName.trim() || createSession.isPending}
                className="w-full h-14 text-xl font-bold rounded-2xl bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 shadow-lg shadow-purple-500/25 transition-all transform hover:scale-[1.02]"
              >
                {createSession.isPending ? <Loader2 className="animate-spin" /> : "Los geht's! 🚀"}
              </Button>
            </form>
          </GlassCard>
        )}

        {step === "question" && (
          <GlassCard key="step-question" className="w-full max-w-lg z-10 text-center py-12">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <h2 className="text-gray-500 text-lg font-medium mb-2 uppercase tracking-widest">
                Eine Frage an {visitorName}
              </h2>
              <h1 className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-br from-purple-600 via-pink-500 to-orange-400 mb-12 leading-tight">
                Magst du mich?
              </h1>
            </motion.div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 min-h-[120px] relative">
              <Button
                onClick={handleYes}
                className="w-40 h-16 text-2xl font-bold rounded-full bg-gradient-to-r from-green-400 to-emerald-600 hover:from-green-500 hover:to-emerald-700 shadow-lg shadow-green-500/30 transform transition-all hover:scale-110 active:scale-95 z-20"
              >
                Jaaaa! 😍
              </Button>

              <div className="relative w-40 h-16 flex items-center justify-center">
                 <FleeingButton onHoverOrClick={handleNoAttempt} />
              </div>
            </div>
            
            <p className="mt-12 text-sm text-gray-400 italic">
              (Sei ehrlich... oder versuch es zumindest 😉)
            </p>
          </GlassCard>
        )}

        {step === "success" && (
          <GlassCard key="step-success" className="w-full max-w-md z-10 text-center py-12">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              type="spring"
              stiffness={200}
            >
              <div className="w-32 h-32 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Heart className="w-16 h-16 text-pink-500 fill-pink-500 animate-pulse" />
              </div>
            </motion.div>
            
            <h1 className="text-4xl font-extrabold text-gray-800 mb-4">
              Juhuuuu! 🎉
            </h1>
            <p className="text-xl text-gray-600">
              Ich wusste es! (Oder hab zumindest sehr gehofft) 
            </p>
            
            <div className="mt-8 p-4 bg-white/50 rounded-xl border border-white/60">
              <p className="text-sm text-gray-500">
                {username} hat sich sicher riesig gefreut.
              </p>
            </div>

            <Button 
              className="mt-8" 
              variant="outline" 
              onClick={() => window.location.href = "/"}
            >
              Selbst so eine Seite erstellen
            </Button>
          </GlassCard>
        )}
      </AnimatePresence>
    </div>
  );
}
