import { useUser, useLogout } from "@/hooks/use-auth";
import { useSessions, useDeleteSessions } from "@/hooks/use-sessions";
import { GlassCard } from "@/components/GlassCard";
import { Button } from "@/components/ui/button";
import { Loader2, LogOut, Trash2, Copy, Check, ExternalLink, Heart, XCircle } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { de } from "date-fns/locale";

export default function Dashboard() {
  const [_, setLocation] = useLocation();
  const { data: user, isLoading: isLoadingUser } = useUser();
  const { data: sessions, isLoading: isLoadingSessions } = useSessions();
  const logoutMutation = useLogout();
  const deleteMutation = useDeleteSessions();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  if (isLoadingUser) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin text-white" /></div>;
  }

  if (!user) {
    setLocation("/");
    return null;
  }

  const publicLink = `${window.location.origin}/u/${user.username}`;

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(publicLink);
      setCopied(true);
      toast({ title: "Kopiert!", description: "Link in die Zwischenablage kopiert." });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({ variant: "destructive", title: "Fehler", description: "Konnte nicht kopiert werden." });
    }
  };

  const handleDeleteHistory = () => {
    if (confirm("Wirklich den gesamten Verlauf löschen?")) {
      deleteMutation.mutate();
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8 relative z-10 flex flex-col items-center">
      <div className="w-full max-w-4xl space-y-6">
        
        {/* Header Section */}
        <GlassCard className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Hallo, <span className="text-gradient">{user.username}</span>! 👋</h1>
            <p className="text-gray-500 mt-1">Hier siehst du wer dich mag.</p>
          </div>
          <Button 
            variant="outline" 
            onClick={() => logoutMutation.mutate()}
            className="rounded-xl border-gray-200 hover:bg-red-50 hover:text-red-500 transition-colors"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </GlassCard>

        {/* Link Section */}
        <GlassCard>
          <h2 className="text-lg font-semibold text-gray-700 mb-3">Dein persönlicher Link</h2>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="flex-1 bg-white/50 border border-white/60 p-3 rounded-xl font-mono text-sm text-gray-600 truncate flex items-center">
              {publicLink}
            </div>
            <div className="flex gap-2">
              <Button onClick={copyLink} className="bg-indigo-600 hover:bg-indigo-700 rounded-xl">
                {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                {copied ? "Kopiert" : "Kopieren"}
              </Button>
              <a href={publicLink} target="_blank" rel="noopener noreferrer">
                <Button variant="secondary" className="bg-white hover:bg-gray-100 rounded-xl">
                  <ExternalLink className="w-4 h-4" />
                </Button>
              </a>
            </div>
          </div>
        </GlassCard>

        {/* Stats Table */}
        <GlassCard className="overflow-hidden p-0">
          <div className="p-6 pb-2 flex justify-between items-center">
            <h2 className="text-xl font-bold text-gray-800">Deine Besucher</h2>
            {sessions && sessions.length > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleDeleteHistory}
                disabled={deleteMutation.isPending}
                className="text-red-400 hover:text-red-600 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Reset
              </Button>
            )}
          </div>
          
          <div className="overflow-x-auto p-6 pt-2">
            {isLoadingSessions ? (
              <div className="py-8 flex justify-center"><Loader2 className="animate-spin text-purple-500" /></div>
            ) : sessions && sessions.length > 0 ? (
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200/50 text-left">
                    <th className="pb-3 text-sm font-medium text-gray-400">Name</th>
                    <th className="pb-3 text-sm font-medium text-gray-400 text-center">Antwort</th>
                    <th className="pb-3 text-sm font-medium text-gray-400 text-center">Nein-Versuche</th>
                    <th className="pb-3 text-sm font-medium text-gray-400 text-right">Zeitpunkt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {sessions.map((session) => (
                    <tr key={session.id} className="hover:bg-white/30 transition-colors">
                      <td className="py-4 font-semibold text-gray-700">{session.visitorName}</td>
                      <td className="py-4 text-center">
                        {session.saidYes ? (
                          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            <Heart className="w-3 h-3 mr-1 fill-green-800" /> Ja
                          </div>
                        ) : (
                          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                            <XCircle className="w-3 h-3 mr-1" /> Offen
                          </div>
                        )}
                      </td>
                      <td className="py-4 text-center text-gray-600 font-mono">
                        {session.noAttempts > 0 ? (
                          <span className="text-orange-500 font-bold">{session.noAttempts}x</span>
                        ) : (
                          <span className="text-gray-300">-</span>
                        )}
                      </td>
                      <td className="py-4 text-right text-gray-500 text-sm">
                        {session.createdAt ? format(new Date(session.createdAt), "dd.MM.yyyy HH:mm", { locale: de }) : "-"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="py-12 text-center text-gray-400">
                <p>Noch keine Besucher. Teile deinen Link!</p>
              </div>
            )}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}
