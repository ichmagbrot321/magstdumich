import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";

interface FleeingButtonProps {
  onHoverOrClick: () => void;
  className?: string;
}

export function FleeingButton({ onHoverOrClick, className }: FleeingButtonProps) {
  // Use absolute positioning relative to a parent container if possible, 
  // but for "fleeing" effectively, fixed/absolute within viewport usually feels best playfully
  
  const [position, setPosition] = useState<{ x: number; y: number } | null>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  
  // Audio for fleeing effect (optional but nice)
  const playFleeSound = () => {
    const audio = new Audio("https://actions.google.com/sounds/v1/cartoon/wood_plank_flicks.ogg");
    audio.volume = 0.5;
    audio.play().catch(() => {}); // Ignore interaction errors
  };

  const moveButton = () => {
    playFleeSound();
    onHoverOrClick();
    
    // Get viewport dimensions
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    // Button dimensions (estimate if not rendered, or use ref)
    const btnWidth = buttonRef.current?.offsetWidth || 100;
    const btnHeight = buttonRef.current?.offsetHeight || 50;

    // Calculate safe area (padding from edges)
    const padding = 20;
    
    const maxX = viewportWidth - btnWidth - padding;
    const maxY = viewportHeight - btnHeight - padding;
    
    const newX = Math.max(padding, Math.floor(Math.random() * maxX));
    const newY = Math.max(padding, Math.floor(Math.random() * maxY));

    setPosition({ x: newX, y: newY });
  };

  return (
    <motion.div
      className={position ? "fixed z-50" : "relative inline-block"}
      style={{
        left: position ? position.x : "auto",
        top: position ? position.y : "auto",
      }}
      animate={position ? { x: 0, y: 0 } : {}}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      <Button
        ref={buttonRef}
        variant="secondary"
        className={`bg-gray-200 hover:bg-gray-300 text-gray-600 font-bold px-8 py-6 text-xl rounded-full transition-all duration-200 ${className}`}
        onMouseEnter={moveButton}
        onTouchStart={moveButton}
        onClick={moveButton} // Last resort if they manage to click it
      >
        Nein
      </Button>
    </motion.div>
  );
}
