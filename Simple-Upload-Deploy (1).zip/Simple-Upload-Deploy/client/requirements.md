## Packages
framer-motion | Complex animations for the fleeing button and page transitions
canvas-confetti | Confetti celebration effect when user clicks "Yes"
@types/canvas-confetti | Types for confetti
date-fns | Date formatting for the dashboard table

## Notes
The app requires a full-screen animated gradient background.
Sounds are played via HTML5 Audio using the provided URLs.
